# ResumeAI - Person 3 Code Package

## Quick Setup

1. **Copy `person3_generation/` folder** to your repo root (alongside `person1_parsing/` and `person2_scoring/`)

2. **Copy `pipeline_COPY_TO_ROOT.py`** to your repo root and rename it to `pipeline.py` (replaces the existing one)

3. **Install dependencies:**
   ```bash
   pip install jinja2 matplotlib seaborn pandas numpy
   ```

4. **For PDF generation**, install LaTeX:
   ```bash
   # Ubuntu/Debian
   sudo apt install texlive-latex-base texlive-fonts-recommended texlive-latex-extra
   
   # macOS
   brew install --cask mactex
   ```

## Final Repo Structure

```
ResumeAI/
├── person1_parsing/      ← Person 1's code
├── person2_scoring/      ← Person 2's code  
├── person3_generation/   ← YOUR CODE (from this package)
│   ├── __init__.py
│   ├── assembler.py
│   ├── latex_generator.py
│   ├── multi_jd_compare.py
│   └── README.md
├── data/
│   ├── mock_data/
│   ├── sample_jds/
│   └── sample_resumes/
├── pipeline.py           ← UPDATED (from this package)
└── requirements.txt
```

## Test It Works

```bash
# Run full pipeline
python pipeline.py --resume data/sample_resumes/milan.pdf --jd data/sample_jds/jd1.txt --output results/

# Or test Stage 3 standalone
cd person3_generation
python assembler.py ../data/mock_data/sample_scored.json -r ../data/mock_data/sample_resume.json -o test.json
```

## Key Integration Note

Person 2's `sample_scored.json` does NOT include contact info. The assembler handles this by accepting the original resume via `-r` flag, or the pipeline passes it automatically.

## Files Included

- `person3_generation/` - Your Stage 3 code
- `pipeline_COPY_TO_ROOT.py` - Updated pipeline that runs all 3 stages
- `data/mock_data/` - Test data from Person 2 for verification
