"""
pipeline.py
-----------
Wires all 3 stages together into one end-to-end run.

Usage:
    python pipeline.py --resume data/sample_resumes/milan.pdf --jd data/sample_jds/jd1.txt
    python pipeline.py --resume data/sample_resumes/milan.pdf --jd data/sample_jds/jd1.txt --output results/

What it does:
    Stage 1 (Person 1): parse the PDF resume + JD text into clean JSON
    Stage 2 (Person 2): score every bullet semantically and with TF-IDF, run gap analysis
    Stage 3 (Person 3): assemble tailored resume and generate PDF via LaTeX
"""

import argparse
import json
import os
import sys

# make sure the sub-packages are importable when running from the repo root
sys.path.insert(0, os.path.dirname(__file__))

from person1_parsing.resume_parser import parse_resume
from person1_parsing.jd_parser import parse_jd
from person2_scoring.scorer import score_resume
from person3_generation.assembler import assemble, save_assembled
from person3_generation.latex_generator import generate, generate_tex_only


def run_pipeline(resume_pdf_path, jd_source, output_dir=None):
    """
    Full pipeline: PDF + JD text -> tailored resume PDF.

    resume_pdf_path: path to the master resume PDF
    jd_source:       either a path to a .txt file or raw JD text as a string
    output_dir:      where to save all outputs (optional, defaults to 'output/')
    """
    
    # Set default output directory
    if output_dir is None:
        output_dir = 'output'
    os.makedirs(output_dir, exist_ok=True)

    # ── Stage 1: parse ──────────────────────────────────────────────────────
    print(f"\n{'='*60}")
    print("[Stage 1] PARSING")
    print('='*60)
    
    print(f"Parsing resume: {resume_pdf_path}")
    resume = parse_resume(resume_pdf_path)
    print(f"  ✓ Parsed {len(resume['sections']['experience'])} experience entries")
    print(f"  ✓ Parsed {len(resume['sections']['projects'])} projects")
    print(f"  ✓ Detected {len(resume['all_skills_detected'])} skills")

    # figure out if jd_source is a file path or raw text
    if os.path.isfile(jd_source):
        with open(jd_source) as f:
            jd_text = f.read()
        print(f"\nParsing JD from file: {jd_source}")
    else:
        jd_text = jd_source
        print(f"\nParsing JD from raw text ({len(jd_text)} chars)")

    jd = parse_jd(jd_text)
    print(f"  ✓ Role: {jd['title']} @ {jd['company']}")
    print(f"  ✓ {len(jd['requirements']['required_skills'])} required skills")
    print(f"  ✓ {len(jd['requirements']['preferred_skills'])} preferred skills")

    # Save intermediate outputs
    resume_json_path = os.path.join(output_dir, 'parsed_resume.json')
    jd_json_path = os.path.join(output_dir, 'parsed_jd.json')
    with open(resume_json_path, 'w') as f:
        json.dump(resume, f, indent=2)
    with open(jd_json_path, 'w') as f:
        json.dump(jd, f, indent=2)

    # ── Stage 2: score ──────────────────────────────────────────────────────
    print(f"\n{'='*60}")
    print("[Stage 2] SCORING")
    print('='*60)
    
    print("Running scoring pipeline...")
    scored = score_resume(resume, jd)

    print(f"\n  ✓ Overall semantic score: {scored['overall_semantic_score']:.1%}")
    print(f"  ✓ Overall keyword score:  {scored['overall_keyword_score']:.1%}")
    print(f"  ✓ Covered skills:  {', '.join(scored['skills_analysis']['covered'][:5])}...")
    print(f"  ✓ Missing skills:  {', '.join(scored['skills_analysis']['missing']) or 'None!'}")

    # Save scored output
    scored_json_path = os.path.join(output_dir, 'scored_resume.json')
    with open(scored_json_path, 'w') as f:
        json.dump(scored, f, indent=2)

    # ── Stage 3: assemble + generate ────────────────────────────────────────
    print(f"\n{'='*60}")
    print("[Stage 3] ASSEMBLY & GENERATION")
    print('='*60)
    
    print("Assembling tailored resume...")
    assembled = assemble(scored, jd_data=jd, original_resume=resume)
    
    print(f"  ✓ Selected {assembled['metadata']['experiences_included']} experiences")
    print(f"  ✓ Total bullets: {assembled['metadata']['total_bullets']}")
    print(f"  ✓ Skills included: {len(assembled['skills'])}")

    # Save assembled JSON
    assembled_json_path = os.path.join(output_dir, 'assembled_resume.json')
    save_assembled(assembled, assembled_json_path)

    # Generate PDF
    pdf_path = os.path.join(output_dir, 'tailored_resume.pdf')
    print(f"\nGenerating PDF: {pdf_path}")
    
    pdf_success = generate(assembled, pdf_path, keep_tex=True)
    
    if not pdf_success:
        # If PDF generation failed (no pdflatex), we still have the .tex file
        tex_path = pdf_path.replace('.pdf', '.tex')
        print(f"  ⚠ PDF generation failed (pdflatex not found)")
        print(f"  ✓ LaTeX source saved to: {tex_path}")
        print(f"  → Upload to Overleaf or install TeX Live to compile")

    # ── Summary ─────────────────────────────────────────────────────────────
    print(f"\n{'='*60}")
    print("PIPELINE COMPLETE")
    print('='*60)
    print(f"\nOutputs saved to: {output_dir}/")
    print(f"  • parsed_resume.json   (Stage 1)")
    print(f"  • parsed_jd.json       (Stage 1)")
    print(f"  • scored_resume.json   (Stage 2)")
    print(f"  • assembled_resume.json (Stage 3)")
    print(f"  • tailored_resume.pdf  (Stage 3)" if pdf_success else f"  • tailored_resume.tex  (Stage 3)")
    
    # Gap report
    gap = assembled['gap_report']
    if gap['missing']:
        print(f"\n⚠️  Skills gap detected:")
        for skill in gap['missing']:
            print(f"   • Missing: {skill}")
    
    if gap['recommendations']:
        print(f"\n📋 Recommendations:")
        for rec in gap['recommendations'][:3]:
            print(f"   • {rec}")

    return {
        'resume': resume,
        'jd': jd,
        'scored': scored,
        'assembled': assembled,
        'output_dir': output_dir
    }


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="ResumeAI — end-to-end pipeline")
    ap.add_argument("--resume", required=True, help="Path to master resume PDF")
    ap.add_argument("--jd", required=True, help="Path to JD text file (or raw JD text)")
    ap.add_argument("--output", default="output", help="Output directory (default: output/)")
    args = ap.parse_args()

    run_pipeline(args.resume, args.jd, args.output)
